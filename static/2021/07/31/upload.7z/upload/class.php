<?php
session_start();

function red($fileinfo){
    foreach($fileinfo as $key => $value){
        $path = $value;
        $name = $key;
    }
    echo "<a style='color:#ff6347' href='$path'>$name</a>\n";
    return $name;
}

function green($fileinfo){
    foreach($fileinfo as $key => $value){
        $path = $value;
        $name = $key;
    }
    echo "<a style='color:#32cd32' href='$path'>$name</a>\n";
    return $name;
}
class file{
    public $path;
    function __construct($path)
    {
        $this->path = $path;
    }
    function __toString()
    {
        return basename($this->path);
    }
}